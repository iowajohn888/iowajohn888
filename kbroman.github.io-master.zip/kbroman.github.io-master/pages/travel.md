---
layout: page
title: travel
---

<!--
  <a href="http://statgen.ncsu.edu/brcwebsite/summer_institute_ral.php">Summer Institute in Statistical Genetics</a> at NC State in Raleigh, NC (June 8-10, 2005)

  <a href="http://www.complextrait.org/meetings/main.php#ctc2005">4th Annual Meeting of the Complex Trait Consortium</a> in Groningen, the Netherlands (June 27-30, 2005)

  <a href="http://math.bnu.edu.cn/statprob/CSPS-IMS2005/index.html">CSPS/IMS meeting</a> in Beijing, China (July 9-12, 2005)

  <a href="http://www.amstat.org/meetings/jsm/2005/index.cfm">Joint Statistical Meetings</a> in Minneapolis, Minnesota (Aug 7-11, 2005)

  <a href="http://www.jax.org/courses/events/coursedetails.do?id=133">Short course on Complex Trait Analysis</a> at the Jackson Lab in Bar Harbor, Maine (Oct 5-11, 2005)

   <a href="http://bioinf.wehi.edu.au/folders/melanie/genemappers/">5th Australiasian human gene mapping conference</a>, <a href="http://www.mtbuller.com.au">Mt. Buller</a>, Australia (Nov 23-25, 2005)

  <a href="http://www.enar.org/meetings.htm">International
  Biometric Society/ENAR meeting</a>, Tampa, Florida (Mar 26-29, 2006)

  <a href="http://www.complextrait.org/meetings/ctc06.php">Complex Trait Consortium meeting</a> in Chapel Hill,
      North Carolina (May 6-10, 2006)

  <a href="http://www.biostat.washington.edu/sisg06/">Summer Institute in Statistical Genetics</a>, Seattle, Washington (June 26-28, 2006)</li>

  Visiting The Jackson Lab, Bar Harbor, Maine (July 10-12, 2006)</li>

  <a href="http://www.jax.org/courses/events/coursedetails.do?id=341&detail=scope">Complex Trait Analysis</a> short course, <a href="http://www.jax.org">The Jackson Laboratory</a>, Bar Harbor, Maine (Sept 16-22, 2006)</li>

  University of Michigan, Ann Arbor (Oct 19-20, 2006)</li>

  Neuropromise training course in Genetic analysis and
      Bioinformatics, Lund, Sweden (Jan 8-12, 2007)</li>

  Systems Medicine Workshop, NHLBI, Bethesda, MD (Jan 30 - Feb 1,
      2007)</li>

  GCAT Study Section (Feb 5-6, 2007)</li>

  Seminar at Statistics, U Michigan, Ann Arbor (Feb 14-16, 2007)</li>

  Seminar at The Jackson Lab, Bar Harbor (Feb 21-24, 2007)</li>

  Seminar at Statistics, UC Berkeley (Feb 27-Mar 1, 2007)</li>

  Seminar at Human Genetics, UCLA (March 5, 2007)</li>

  Seminar at U Wisconsin, Madison (Mar 21-24, 2007)</li>

  <a href="http://www.arvo.org/EWEB/startpage.aspx?site=AM_2007">ARVO</a> (May 6-10, 2007)</li>

  6th CTC meeting, Braunschweig, Germany (May 26 -29, 2007)</li>

  Cancun, Mexico (May 16-23, 2007)</li>

  GCAT Study Section, Washington, DC (May 31-June 1, 2007)</li>

  Seminar at <a href="http://www.math.niu.edu/">University of
      Northern Illinois</a>, DeKalb, Illinois (Sept 10-11, 2007)

  GCAT Study Section, San Francisco (Oct 3-4, 2007)

  <a href="http://www.genetics.wisc.edu/events.page?act=details&event=26">Genetics Dept retreat</a>, Devil's Head Resort, Merrimac, WI (Oct 5, 2007)

  <a href="http://www.jax.org/courses/2007/complextraits07.html">Complex Trait Analysis short course</a> at <a href="http://www.jax.org">The Jackson Laboratory</a>, Bar Harbor, Maine (Oct 11-17, 2007)

  Seminar at <a href="http://www.stolaf.edu">St Olaf College</a>, <a href="http://www.stolaf.edu/depts/statistics">Department of Statistics</a>, Northfield, Minnesota (Nov 5-6, 2007)

  Seminar at <a href="http://www.biostat.jhsph.edu">Johns Hopkins Biostatistics</a> (Nov 28, 2007)

  Seminar at <a href="http://www.genes.uchicago.edu/">Dept of Human Genetics</a>, <a href="http://www.uchicago.edu">University of Chicago</a> (Dec 5, 2007)

  Ani's defense, Johns Hopkins, Baltimore, MD (Dec 7, 2007)

  GCAT Study Section, Washington, DC (Feb 3-5, 2008)

  <a href="http://galton.uchicago.edu/msrc">First Midwest Statistics Research Colloquium</a>, University of Chicago (Mar 28-29, 2008)

  CTC meeting in Chapel Hill, North Carolina (Mar 14-15, 2008)

  Seminar at Cincinnati Children's Hospital (Apr 24-25, 2008)

  <a href="http://www.birs.ca/birspages.php?task=displayevent&event_id=08w5062">Emerging Statistical Challenges in Genome and Translational Research</a>, Banff, Canada (June 1-6, 2008)

  <a href="http://courses.jax.org/2008/systemgenetics08.html">Systems Genetics course</a> at The Jackson Laboratory, Bar Harbor, Maine (Sep 23-29, 2008)

  <a href="http://www-app.igb.uiuc.edu/bioinformatics/index.html">Midwest Symposium on Bioinformatics and Computational Biology</a>, Oct 4, 2008 (Champaign, IL)

  GCAT Study Section, Oct 6-7, 2008 (San Francisco, CA)

  Groningen and Oxford, Jan 17-24, 2009

  GCAT Study Section, Feb 3-4, 2009 (Washington, DC)

  GCAT Study Section, Jun 4-5, 2009 (Washington, DC)

  GCAT Study Section, Oct 14-15, 2009 (Seattle)

  <a href="http://courses.jax.org/2009/systemgenetics09.html">Systems Genetics course</a> at The Jackson Lab, Oct 19-25, 2009 (Bar Harbor)

  <a href="http://www.genetics.ucla.edu/">Human Genetics</a>, <a href="http://www.ucla.edu">UCLA</a>, Nov 23, 2009

  JAX CGD retreat, Jan 14-16, 2010 (Bar Harbor)

  GCAT Study Section, Feb 2-4, 2010 (Washington, DC)

  Seminar at UNC, Feb 11-13, 2010 (Chapel Hill, NC)

  Seminar at Vanderbilt, Mar 8-9, 2010 (Nashville, TN)

  Seminar at Michigan State, Apr 1-3, 2010 (Lansing, MI)

  <a href="http://www.ctc2010.org/">9th CTC meeting</a>, May 7-10, 2010 (Chicago)

  <a href="http://jay.up.poznan.pl/qtlmas2010/">MAS-QTL Workshop</a> and visit to Worclaw, May 17-18, 2010 (Poland)

  GCAT Study Section, Jun 2-3, 2010 (Chicago)

  <a href="http://www.cidr.jhmi.edu/cac.html">CIDR Access Committee</a>, Sept 7-8, 2010 (Washington, DC)

  <a href="http://courses.jax.org/2010/systemgenetics10.html">Systems Genetics course</a> at The Jackson Lab, Sep 19-25, 2010 (Bar Harbor)

  CGD meeting at The Jackson Lab, Jan 19-21, 2011 (Bar Harbor)

  Seminar in <a href="http://www.mailman.columbia.edu/academic-departments/biostatistics">Biostatistics</a> at <a href="http://www.columbia.edu">Columbia University</a>, Jan 26-28, 2011 (New York, NY)

  <a href="http://www.bio-complexity.com/QUB11/QB_ConfIndex.html">Quantitative Biology and Bioinformatics in Modern Medicine</a>, Feb 7-8, 2011 (Dublin, Ireland)

  <a href="http://cgd.jax.org/events/systemsgeneticsresources.shtml">Systems Genetics Resources Workshop</a>, May 12-13, 2011 (Chapel Hill, NC)

  <a href="http://www.ctc2010.org/">Mouse Genetics meeting</a>, Jun 22-26, 2011 (Washington, DC)

  <a href="http://www.warwick.ac.uk/statsdept/useR-2011/">UseR! Meeting</a>, Aug 16-18, 2011 (Coventry, UK)

  <a href="http://www.rug.nl/informatica/index">Groningen</a>, The Netherlands, Sept 6-11, 2011)

  <a href="http://statistics.gmu.edu/">Statistics</a>, <a href="http://www.gmu.edu">George Mason University</a>, Sept 22-23, 2011 (near Washington, DC)

  <a href="http://courses.jax.org/2011/systems-genetics.html">Systems Genetics course</a> at The Jackson Lab, Oct 2-9, 2011 (Bar Harbor)

  <a href="http://www.biostat.washington.edu/">Department of Biostatistics</a>, <a href="http://www.washington.edu">U Washington, Seattle</a>, Nov 16-18, 2011

  <a href="http://www.cidr.jhmi.edu/cac.html">CIDR Access Committee</a>, Jan 12-13, 2012 (Washington, DC)

  JAX CGD retreat, Jan 20, 2012 (Bar Harbor)

  <a href="http://www.enar.org/meetings.cfm">ENAR 2012 meeting</a>, Apr 1-4, 2012 (Washington, DC)

  <a href="http://www.pasteur.fr/ip/easysite/pasteur/en/research/scientific-departments/developmental-biology/units-and-groups/mouse-functional-genetics/ctc2012">CTC Meeting</a>, June 12-15, 2012 (Paris)

  <a href="http://www.euratrans.eu/">Euratrans</a> meeting, June 3-5, 2012 (Tutzing, Germany)

  CGD Advisory Board, Jackson Lab, Aug 15, 2012 (Bar Harbor)

  <a href="http://courses.jax.org/2012/systems-genetics.html">Systems Genetics course</a> at The Jackson Lab, Oct 28-Nov 4, 2012 (Bar Harbor)

  QTL course, <a href="http://www.icrisat.org">ICRISAT</a>, Dec 3-5, 2012 (Hyderabad, Andhra Pradesh, India)

  JAX CGD retreat, Jan 17, 2013 (North Carolina)

  <a href="http://www.enar.org/meetings.cfm">ENAR</a>, Mar 10-13, 2013 (Orlando, Florida)

  Plant breeding and genetics meeting, <a href="http://www.agronomy.ksu.edu/p.aspx?tabid=223">Kansas State Univ</a>, Apr 2, 2013 (Manhattan, KS)

  <a href="http://mus.well.ox.ac.uk/19genomes/MAGIC-WORKSHOP/">MAGIC workshop</a>, June 12-13, 2013 (Cambridge, UK)

  CGD Advisory Board, Jackson Lab, June 25, 2013 (Bar Harbor)</li>

  <a href="http://courses.jax.org/2013/systems-genetics.html">Systems Genetics course</a> at The Jackson Lab, Sep 8-14, 2013 (Bar Harbor)</li>

  <a href="http://www.cidr.jhmi.edu/cac.html">CIDR Access Committee</a>, Sep 12, 2013 (Washington, DC)</li>

  <a href="http://wssspe.researchcomputing.org.uk/cfp/">Workshop on sustainable software</a>, Nov 17, 2013 (Denver, CO)</li>

  JAX CGD retreat, Jan 21, 2014 (North Carolina)</li>

  <a href="http://www.danforthcenter.org/">Donald Danforth Plant Science Center</a>, Feb 18-20, 2014 (St. Louis)</li>

  <a href="http://enar.org/meetings.cfm">ENAR</a>, Mar 16-19, 2014 (Baltimore)</li>

  <a href="http://www.ctc2014.org/">Complex Trait Community meeting</a>, May 19-22, 2014 (Berlin, Germany)</li>

  <a href="http://user2014.stat.ucla.edu/">2014 UseR conference</a>, June 30 - July 3, 2014 (Los Angeles, CA)</li>

  <a href="http://biovis.net">4th Symposium on Biological Data Visualization</a>, July 11-12, 2014 (Boston, MA)</li>

- [Washington State University](http://www.wsu.edu), Aug 4-7, 2014
  (Pullman, WA)

- [CIDR Access Committee](http://www.cidr.jhmi.edu/about/history.html), Sep 12,
  2014 (Baltimore, MD)

- [Systems Genetics course](http://courses.jax.org/2014/systems-genetics.html),
  The Jackson Lab, Sep 27-Oct 3, 2014 (Bar Harbor, ME)

- Seminar at [Harvard Biostat](http://www.hsph.harvard.edu/biostatistics/),
  Nov 6, 2014 (Boston, MA)

- Reproducible Research hackathon, Dec 8-11, 2014 (Durham, NC)

- Jackson Lab, Jan 6-9, 2015 (Bar Harbor, Maine)

- [AAAS meeting](https://aaas.confex.com/aaas/2015/webprogram/start.html), Feb 12-16, 2015 (San Jose, CA)

- [Genome to Phenome Symposium](http://www.csiro.au/Portals/Events/Queensland/OCE_Genome-phenome.aspx), Mar 25-27, 2015 (Brisbane, Australia)

- [Software Carpentry workshop](http://karawoo.com/2015-04-27-wsu/), Apr 27-28, 2015 (Pullman, WA)

- [CTC meeting](http://www.ohsu.edu/parc/CTC2015), June 8-11, 2015 (Portland, OR)

- [R/Bioconductor conference](http://bioconductor.org/help/course-materials/2015/BioC2015/),
  July 20-22, 2015 (Seattle, WA)

- [JSM 2015](http://www.amstat.org/meetings/jsm/2015/), Aug 8-13, 2015 (Seattle, WA)

- R/qtl workshop at Texas A&amp;M, Sep 1-4, 2015 (College Station, TX)

- [JHU Data Science Hackathon](https://www.regonline.com/builder/site/Default.aspx?EventID=1692764), Sep 21-23, 2015 (Baltimore, MD)

- [Systems Genetics course](https://www.jax.org/education-and-learning/education-calendar/2015/september/short-course-on-systems-genetics),
  The Jackson Lab, Sep 27-Oct 3, 2015 (Bar Harbor, ME)

- Memphis trip to meet with Saunak and Pjotr, Nov 1-5, 2015 (Memphis, TN)

- Alexander Disease project meeting, Nov 14, 2015 (Boston, MA)

- Chicago ASA talk, East Bank Club, 500 N Kingsbury St, Dec 15, 2015 (Chicago, IL)

- [ENAR](http://enar.org/meetings.cfm), Mar 6-9, 2016 (Austin, TX)

- Jackson Lab, Feb 8-11, 2016

- Genentech, Mar 14-16, 2016 (San Francisco, CA)

- Chicago ASA workshop on reproducible research, Apr 1, 2016 (Chicago, IL)

- [Biological Statistics and Computational Biology](https://bscb.cornell.edu/),
  Cornell University, Apr 18, 2016 (Ithaca, NY)

- Albee Messing project meeting, May 12-13, 2016 (Rochester, NY)

- PRDM9 advisory board meeting, May 17-20, 2016 (Bar Harbor, ME)

- [International Conference on Quantitative Genetics](http://www.icqg5.org/)
  June 12-17, 2016 (Madison, WI)

- [UseR! conference](http://user2016.org/), Stanford, June 27-30, 2016
  (Palo Alto, CA)

- [The Allied Genetics Conference](http://www.genetics2016.org/), July
  13-17, 2016 (Orlando, FL)

- [JSM 2016](http://www.amstat.org/meetings/jsm/2016), July 31-Aug 4,
  2016 (Chicago, IL)

- [Queenstown Research Week Genomics (MapNet) Satellite Conference](http://www.queenstownresearchweek.org/),
  Sep 1-2, 2016 (Nelson, New Zealand)

- [Systems Genetics course](https://www.jax.org/education-and-learning/education-calendar/2016/october/short-course-on-systems-genetics)
  The Jackson Lab, Oct 16-22, 2016 (Bar Harbor, ME)

- Meet with Pjotr et al., Nov 7-10, 2016 (Memphis, TN)

- Seminar at NC State, Feb 5-7, 2017 (Raleigh, NC)

- Jackson Lab, Feb 14-17, 2017 (Bar Harbor, ME)

- [Gordon Conference on Quantitative Genetics](https://www.grc.org/programs.aspx?id=12073), Feb 27 - Mar 3, 2017
  (Galveston, TX)

- U Minnesota Plant Breeding Symposium, Mar 23-24, 2017 (St Paul, MN)

- Seminar at [BIDS](https://bids.berkeley.edu/), UC-Berkeley, Apr 5-8, 2017 (Berkeley, CA)

- [OpenVis Conference](https://openvisconf.com), Apr 23-26, 2017 (Boston, MA)

- Albee Messing project meeting, May 18-19, 2017 (Boston, MA)

- [ROpenSci unconference](http://unconf17.ropensci.org/), May 24-27,
  2017 (Los Angeles, CA)

- [CTC meeting](http://www.complextrait.org/ctc2017), June 13-17, 2017 (Memphis, TN)

- Camping, July 3-7, 2017 (Devil's Lake, WI)

- [Reproducible Research course](https://www.biostat.washington.edu/suminst/sisbid2017/modules/BD1703), July 16-20, 2017 (Seattle, WA)

- [Systems Genetics of Neurodegenerative Disease course](http://sgn2017.org/), Aug 24-Sept 1,
  2017 ([Frauenchiemsee, Germany](http://bit.ly/2hxaxD4))

- Seminar in [Bioinformatics](http://bioinformatics.uncc.edu/) at
  [UNC-Charlotte](http://www.uncc.edu), Sep 21-22, 2017 (Charlotte,
  NC)

- [Statfest](http://community.amstat.org/cmis/events/statfest), Emory University, Sep 23, 2017 (Atlanta, GA)

- Data Carpentry Workshop, NBSE Professional Development Conference,
  Sept 28, 2018 (Chicago, IL)

- [John Novembre](https://jnpopgen.org/), U Chicago, Nov 15-17, 2017

- UCSF seminar, Jan 31-Feb 2, 2018 (San Francisco, CA)

- GeneNetwork hackathon, Feb 26-Mar 1, 2018 (Memphis, TN)

-->

- Seminar at Dept of Statistics, Colorado State University, Apr 23,
  2018 (Fort Collins, CO)

- [Population, Evolutionary, & Quantitative Genetics Conference (PEQG)](http://genetics-gsa.org/peqg/2018/),
  May 13-16, 2018 (Madison, WI)

- [Purdue Symposium on Statistics](http://www.stat.purdue.edu/symp2018/schedule/sessions/index.html),
  June 6-8, 2018 (West Lafayette, IN)

- [CTC meeting](http://www.complextrait.org/ctc2018/), June 20-22, 2018 (Glasgow, Scotland)

- Reproducible Research course, [Summer Institute for Big Data](http://www.biostat.washington.edu/suminst/sisbid), July 16-18, 2018 (Seattle, WA)

- [AAAS meeting](http://meetings.aaas.org), Feb 14-18, 2019 (Washington, DC)

---

[UW-Madison travel policies](http://www.bussvc.wisc.edu/acct/policy/ppindex.html)
